const CACHE_NAME = 'daily-life-v1';
const ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/app_icon_futuristic.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS);
    })
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request);
    })
  );
});
