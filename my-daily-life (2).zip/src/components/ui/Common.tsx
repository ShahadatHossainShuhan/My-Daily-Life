import React from 'react';
import { motion } from 'motion/react';
import { cn } from '@/src/lib/utils';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  glow?: boolean;
  onClick?: () => void;
}

export function GlassCard({ children, className, glow = false, onClick }: GlassCardProps) {
  return (
    <motion.div
      onClick={onClick}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "glass-card overflow-hidden",
        glow && "border-neon-cyan/30 shadow-[0_0_20px_rgba(0,242,255,0.1)]",
        className
      )}
    >
      {children}
    </motion.div>
  );
}

export function NeonButton({ children, onClick, className, variant = 'primary', size = 'md' }: any) {
  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={cn(
        "relative overflow-hidden rounded-xl font-medium transition-all duration-300",
        size === 'sm' ? "px-3 py-1.5 text-xs" : "px-6 py-3 text-sm",
        variant === 'primary' ? "bg-neon-cyan text-navy-black shadow-[0_0_15px_rgba(0,242,255,0.4)]" : "bg-white/10 text-white border border-white/10",
        className
      )}
    >
      {children}
    </motion.button>
  );
}
