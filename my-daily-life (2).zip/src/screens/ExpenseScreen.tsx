import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, X, Search, Filter, TrendingUp, TrendingDown, Trash2, Calendar as CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react';
import { GlassCard, NeonButton } from '../components/ui/Common';
import { dbService, type Transaction } from '../lib/db';
import { format, isSameDay, startOfMonth, startOfWeek, addMonths, subMonths } from 'date-fns';
import { cn } from '../lib/utils';
import confetti from 'canvas-confetti';
import { translations } from '../lib/i18n';

export default function ExpenseScreen({ language }: { language: string, key?: string }) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filter, setFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState<string>('');
  const [selectedMonth, setSelectedMonth] = useState(new Date());
  
  const t = translations[language];

  // Modal State
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<'income' | 'expense'>('expense');

  useEffect(() => {
    loadTransactions();
  }, []);

  async function loadTransactions() {
    const data = await dbService.getAll('transactions');
    setTransactions(data.sort((a, b) => b.date.getTime() - a.date.getTime()));
  }

  const handleAdd = async () => {
    if (!title || !amount) return;
    
    await dbService.add('transactions', {
      title,
      amount: parseFloat(amount),
      type,
      date: new Date(),
    });
    
    if (type === 'income') {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#00f2ff', '#0066ff']
      });
    }

    setTitle('');
    setAmount('');
    setType('expense');
    setIsModalOpen(false);
    loadTransactions();
  };

  const handleDelete = async (id: string | undefined) => {
    if (!id) return;
    await dbService.delete('transactions', id);
    loadTransactions();
  };

  const filteredTransactions = transactions.filter(tx => {
    const matchesType = filter === 'all' || tx.type === filter;
    const matchesDate = !dateFilter || isSameDay(tx.date, new Date(dateFilter));
    return matchesType && matchesDate;
  });

  const groupedTransactions = React.useMemo(() => {
    const groups: { [key: string]: Transaction } = {};
    filteredTransactions.forEach(tx => {
      const dateStr = format(tx.date, 'yyyy-MM-dd');
      const key = `${tx.title.toLowerCase().trim()}-${dateStr}-${tx.type}`;
      if (groups[key]) {
        groups[key].amount += tx.amount;
      } else {
        groups[key] = { ...tx };
      }
    });
    return Object.values(groups).sort((a, b) => b.date.getTime() - a.date.getTime());
  }, [filteredTransactions, format]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="space-y-6"
    >
      <div className="flex flex-col gap-6">
        <h1 className="text-2xl font-bold tracking-tight">{t.financialHistory}</h1>
        
        <div className="space-y-4">
          <div className="flex items-center gap-3 w-full">
             <div className="flex flex-1 p-1 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl gap-1">
              {(['all', 'expense', 'income'] as const).map((ti) => (
                <button 
                  key={ti}
                  onClick={() => setFilter(ti)} 
                  className={cn(
                    "flex-1 py-2 rounded-xl text-[10px] uppercase font-bold tracking-tighter transition-all", 
                    filter === ti ? "bg-neon-cyan text-navy-black shadow-[0_0_15px_rgba(34,211,238,0.3)]" : "text-white/40 hover:text-white/60"
                  )}
                >
                  {ti === 'all' ? t.all : ti === 'expense' ? t.spent : t.income}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between gap-4">
             <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-2xl px-4 py-2 flex-1 relative overflow-hidden group">
                <CalendarIcon size={14} className="text-neon-cyan" />
                <input 
                  type="date"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                  className="bg-transparent text-xs text-white outline-none w-full appearance-none relative z-10"
                />
                {!dateFilter && <span className="absolute left-10 text-[10px] text-white/20 pointer-events-none uppercase tracking-widest">{t.selectDate}</span>}
                {dateFilter && (
                   <button onClick={() => setDateFilter('')} className="text-neon-pink ml-2 relative z-10">
                     <X size={14} />
                   </button>
                )}
             </div>

             <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-2xl px-3 py-2">
                <button onClick={() => setSelectedMonth(subMonths(selectedMonth, 1))} className="text-white/40 hover:text-white"><ChevronLeft size={16} /></button>
                <span className="text-[10px] font-bold uppercase tracking-widest w-20 text-center">{format(selectedMonth, 'MMM yyyy')}</span>
                <button onClick={() => setSelectedMonth(addMonths(selectedMonth, 1))} className="text-white/40 hover:text-white"><ChevronRight size={16} /></button>
             </div>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {groupedTransactions.length > 0 ? (
          <div className="space-y-3">
            {groupedTransactions.map((tx, i) => (
              <motion.div
                key={tx.id || i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <GlassCard className="p-4 flex items-center justify-between group hover:border-white/30">
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "p-2.5 rounded-xl transition-all duration-300",
                      tx.type === 'income' ? "bg-neon-cyan/20 text-neon-cyan group-hover:shadow-[0_0_15px_rgba(0,242,255,0.3)]" : "bg-neon-pink/20 text-neon-pink group-hover:shadow-[0_0_15px_rgba(255,0,122,0.3)]"
                    )}>
                      {tx.type === 'income' ? <TrendingUp size={18} /> : <TrendingDown size={18} />}
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm text-white/90">{tx.title}</h4>
                      <p className="text-[10px] text-white/40 mt-0.5 tracking-wider uppercase font-medium">{format(tx.date, language === 'English' ? 'MMMM dd, yyyy' : 'dd MMMM, yyyy')}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "text-right font-bold text-lg tabular-nums transition-all duration-300",
                      tx.type === 'income' ? "text-neon-cyan drop-shadow-[0_0_10px_rgba(0,242,255,0.3)]" : "text-neon-pink"
                    )}>
                      {tx.type === 'income' ? '+' : '-'}{t.currencySymbol}{tx.amount.toLocaleString()}
                    </div>
                    <button 
                      onClick={() => handleDelete(tx.id!)}
                      className="opacity-0 group-hover:opacity-100 p-2 text-white/20 hover:text-neon-pink transition-all"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="py-20 text-center space-y-3">
            <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto border border-white/10">
              <Search size={32} className="text-white/10" />
            </div>
            <p className="text-white/20 italic text-sm">{t.noRecordsFound}</p>
          </div>
        )}
      </div>

      {/* FAB */}
      <motion.button
        whileHover={{ scale: 1.1, rotate: 90 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsModalOpen(true)}
        className="fixed bottom-28 right-8 w-14 h-14 bg-neon-cyan text-navy-black rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(0,242,255,0.5)] z-40"
      >
        <Plus size={28} />
      </motion.button>

      {/* Add Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-navy-black/80 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="glass-card w-full max-w-sm p-8 relative z-10 border-white/20 shadow-2xl"
            >
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-xl font-bold">{t.newRecord}</h3>
                <button onClick={() => setIsModalOpen(false)} className="text-white/40 hover:text-white">
                  <X size={24} />
                </button>
              </div>

              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-bold tracking-widest text-white/40 ml-1">{t.title}</label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder={language === 'English' ? "e.g. Freelance Pay" : "যেমন: ফ্রিল্যান্সিং"}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-neon-cyan transition-all"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-bold tracking-widest text-white/40 ml-1">{t.amount} ({t.currencySymbol})</label>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-neon-cyan transition-all font-mono"
                  />
                </div>

                <div className="flex gap-2 p-1 bg-white/5 rounded-xl">
                  <button
                    onClick={() => setType('expense')}
                    className={cn(
                      "flex-1 py-3 rounded-lg text-xs font-bold uppercase tracking-wider transition-all",
                      type === 'expense' ? "bg-neon-pink text-white shadow-lg" : "text-white/30"
                    )}
                  >
                    {t.spent}
                  </button>
                  <button
                    onClick={() => setType('income')}
                    className={cn(
                      "flex-1 py-3 rounded-lg text-xs font-bold uppercase tracking-wider transition-all",
                      type === 'income' ? "bg-neon-cyan text-navy-black shadow-lg" : "text-white/30"
                    )}
                  >
                    {t.income}
                  </button>
                </div>

                <NeonButton onClick={handleAdd} className="w-full py-4 text-sm mt-4">
                  {t.addTransaction}
                </NeonButton>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
