import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { User, Mail, Shield, Download, Upload, Trash2, Bell, Globe, Lock, Share2, Camera, Edit2, ChevronRight, X } from 'lucide-react';
import { GlassCard, NeonButton } from '../components/ui/Common';
import { dbService, type UserProfile, type Transaction } from '../lib/db';
import { cn } from '../lib/utils';
import confetti from 'canvas-confetti';
import { AnimatePresence } from 'motion/react';
import { translations } from '../lib/i18n';

export default function ProfileScreen({ user, onUpdateUser, language, onLanguageChange }: { user: UserProfile, onUpdateUser: (u: UserProfile) => void, language: string, onLanguageChange: (l: string) => void, key?: string }) {
  const [stats, setStats] = useState({ totalIncome: 0, totalSpent: 0, savings: 0 });
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(user.name);
  const [editedEmail, setEditedEmail] = useState(user.email);
  const [appLockPin, setAppLockPin] = useState('Not Set');
  const [isPinModalOpen, setIsPinModalOpen] = useState(false);
  const [newPin, setNewPin] = useState('');
  
  const t = translations[language];

  useEffect(() => {
    async function loadData() {
      const txs = await dbService.getAll('transactions');
      const s = txs.reduce((acc, tx) => {
        if (tx.type === 'income') acc.totalIncome += tx.amount;
        else acc.totalSpent += tx.amount;
        return acc;
      }, { totalIncome: 0, totalSpent: 0, savings: 0 });
      
      s.savings = s.totalIncome - s.totalSpent;
      setStats(s);

      const pin = await dbService.getSetting('appLockPin');
      if (pin) setAppLockPin(pin);
    }
    loadData();
  }, [user]);

  const handleUpdateProfile = async () => {
    const updated = { ...user, name: editedName, email: editedEmail };
    await dbService.saveProfile(updated);
    onUpdateUser(updated);
    setIsEditing(false);
    confetti({ particleCount: 30, spread: 40 });
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = reader.result as string;
        const updated = { ...user, avatar: base64String };
        await dbService.saveProfile(updated);
        onUpdateUser(updated);
        confetti({ particleCount: 50, spread: 60 });
      };
      reader.readAsDataURL(file);
    }
  };

  const toggleLanguage = async () => {
    const newLang = language === 'English' ? 'Bengali' : 'English';
    onLanguageChange(newLang);
    await dbService.saveSetting('language', newLang);
  };

  const handleSavePin = async () => {
    if (newPin.length < 4) {
      alert(language === 'English' ? 'PIN must be at least 4 digits' : 'পিন কমপক্ষে ৪ ডিজিটের হতে হবে');
      return;
    }
    await dbService.saveSetting('appLockPin', newPin);
    setAppLockPin(newPin);
    setIsPinModalOpen(false);
    setNewPin('');
    confetti({ particleCount: 40, colors: ['#22d3ee'] });
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'My Daily Life',
          text: 'Check out this awesome daily life tracker app!',
          url: window.location.href,
        });
      } catch (err) {
        console.error('Share failed:', err);
      }
    } else {
      alert(language === 'English' ? 'Sharing not supported on this browser.' : 'এই ব্রাউজারে শেয়ারিং সমর্থিত নয়।');
    }
  };

  const handleBackup = async () => {
    const transactions = await dbService.getAll('transactions');
    const schedules = await dbService.getAll('schedules');
    const academic = await dbService.getAll('academic');
    const data = { transactions, schedules, academic, user };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `my-daily-life-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleClearData = async () => {
    const confirmMsg = language === 'English' 
      ? 'Are you sure you want to clear ALL data? This cannot be undone.' 
      : 'আপনি কি নিশ্চিত যে আপনি সব ডেটা মুছে ফেলতে চান? এটি আর ফিরে পাওয়া সম্ভব নয়।';
      
    if (confirm(confirmMsg)) {
      localStorage.clear();
      const request = indexedDB.deleteDatabase('my-daily-life-db');
      request.onsuccess = () => {
        window.location.reload();
      };
      request.onerror = () => {
        alert('Could not clear database. Please try clearing browser cache.');
      };
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-8 pb-20">
      <div className="flex flex-col items-center gap-4 py-4">
        <div className="relative group">
          <div className="w-32 h-32 rounded-full p-1 bg-gradient-to-tr from-neon-cyan via-white/20 to-neon-blue shadow-[0_0_30px_rgba(34,211,238,0.3)] group-hover:shadow-[0_0_50px_rgba(34,211,238,0.5)] transition-all duration-500">
            <div className="w-full h-full rounded-full bg-navy-black/80 backdrop-blur-md p-1 overflow-hidden">
              <img src={user.avatar} alt="Avatar" className="w-full h-full rounded-full object-cover transition-transform duration-500 group-hover:scale-110" referrerPolicy="no-referrer" />
            </div>
          </div>
          <label className="absolute bottom-1 right-1 w-10 h-10 bg-neon-cyan text-navy-black rounded-full flex items-center justify-center border-4 border-navy-black shadow-lg cursor-pointer hover:scale-110 active:scale-95 transition-all">
            <Camera size={16} />
            <input type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
          </label>
        </div>

        <div className="text-center space-y-1 w-full flex flex-col items-center">
          {isEditing ? (
             <div className="space-y-4 w-full max-w-[280px]">
               <div className="space-y-1 text-left">
                 <label className="text-[9px] uppercase font-bold tracking-widest text-white/30 ml-2">{t.fullName}</label>
                 <input 
                   value={editedName} 
                   onChange={e => setEditedName(e.target.value)} 
                   className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-3 outline-none text-center text-lg font-bold focus:border-neon-cyan transition-all"
                   placeholder="Name"
                 />
               </div>
               <div className="space-y-1 text-left">
                 <label className="text-[9px] uppercase font-bold tracking-widest text-white/30 ml-2">{t.emailAddress}</label>
                 <input 
                   value={editedEmail} 
                   onChange={e => setEditedEmail(e.target.value)} 
                   className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-3 outline-none text-center text-xs focus:border-neon-cyan transition-all"
                   placeholder="Email"
                 />
               </div>
               <NeonButton onClick={handleUpdateProfile} size="sm" className="w-full font-bold uppercase tracking-widest py-3">
                 {t.saveChanges}
               </NeonButton>
               <button onClick={() => setIsEditing(false)} className="text-[10px] uppercase font-bold text-white/30 hover:text-white transition-all underline underline-offset-4">
                 {t.cancel}
               </button>
             </div>
          ) : (
            <>
              <div className="flex items-center justify-center gap-2 group cursor-pointer" onClick={() => setIsEditing(true)}>
                <h2 className="text-2xl font-bold tracking-tight text-white group-hover:text-neon-cyan transition-colors">{user.name}</h2>
                <Edit2 size={16} className="text-white/20 group-hover:text-neon-cyan transition-colors" />
              </div>
              <p className="text-white/40 text-sm font-medium">{user.email}</p>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <GlassCard className="p-5 space-y-1 bg-gradient-to-br from-neon-cyan/10 to-transparent border-neon-cyan/20">
          <p className="text-[9px] uppercase font-bold tracking-widest text-neon-cyan/60">{t.savings}</p>
          <p className="text-xl font-bold tabular-nums text-white">{t.currencySymbol}{stats.savings.toLocaleString()}</p>
        </GlassCard>
        <GlassCard className="p-5 space-y-1 border-white/10">
          <p className="text-[9px] uppercase font-bold tracking-widest text-white/30">{t.spent}</p>
          <p className="text-xl font-bold tabular-nums text-white">{t.currencySymbol}{stats.totalSpent.toLocaleString()}</p>
        </GlassCard>
      </div>

      <div className="space-y-6">
        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-white/20 ml-2">{t.settingsSecurity}</h3>
        
        <div className="space-y-3">
          <SettingItem icon={<Globe className="text-neon-blue" />} label={t.language} value={language} onClick={toggleLanguage} />
          <SettingItem icon={<Lock className="text-neon-cyan" />} label={t.appLock} value={appLockPin} onClick={() => setIsPinModalOpen(true)} />
          <SettingItem icon={<Bell className="text-neon-cyan" />} label={t.testNotification} onClick={() => {
             if (Notification.permission === 'granted') {
               new Notification(language === 'English' ? "PWA App Active" : "অ্যাপটি সচল রয়েছে", { 
                 body: language === 'English' ? "Your daily life tracker is monitoring your progress." : "আপনার প্রতিদিনের কাজের ট্র্যাকার চলছে।",
                 icon: '/pwa-192x192.png'
               });
             } else {
               Notification.requestPermission().then(permission => {
                 if (permission === 'granted') {
                   new Notification(language === 'English' ? "PWA App Active" : "অ্যাপটি সচল রয়েছে", { 
                     body: language === 'English' ? "Notifications are now active!" : "নোটিফিকেশন এখন সচল!",
                   });
                 } else {
                   alert(language === 'English' ? "Please enable notifications in your browser settings." : "ব্রাউজার সেটিংসে নোটিফিকেশন চালু করুন।");
                 }
               });
             }
          }} />
          <SettingItem icon={<Share2 className="text-neon-cyan" />} label={t.shareApp} onClick={handleShare} />
        </div>

        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-white/20 ml-2">{t.dataManagement}</h3>
        <div className="space-y-3">
          <SettingItem icon={<Download className="text-neon-blue" />} label={t.backupData} onClick={handleBackup} />
          <SettingItem icon={<Trash2 className="text-neon-pink" />} label={t.clearAll} onClick={handleClearData} danger />
        </div>
      </div>

      <AnimatePresence>
        {isPinModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsPinModalOpen(false)} className="absolute inset-0 bg-navy-black/90 backdrop-blur-md" />
            <motion.div initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 20 }} className="glass-card w-full max-w-[320px] p-8 relative z-10 border-white/20 shadow-2xl">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold">{t.setPin}</h3>
                <button onClick={() => setIsPinModalOpen(false)} className="text-white/40 hover:text-white"><X size={20} /></button>
              </div>
              
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-bold tracking-widest text-white/40 ml-1">{t.enterNewPin}</label>
                  <input 
                    type="password" 
                    value={newPin}
                    onChange={(e) => {
                      const val = e.target.value.replace(/\D/g, '').slice(0, 4);
                      setNewPin(val);
                    }}
                    placeholder="****"
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-4 text-center text-2xl font-black tracking-[1em] outline-none focus:border-neon-cyan transition-all"
                  />
                </div>
                
                <NeonButton onClick={handleSavePin} className="w-full py-4 font-bold uppercase tracking-widest">
                  {t.savePin}
                </NeonButton>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="pt-8 text-center pb-8">
        <div className="inline-block px-3 py-1 bg-white/5 rounded-full border border-white/5">
          <p className="text-[9px] text-white/30 uppercase font-bold tracking-[0.4em]">v2.0.4 • DELTA OS • Shahadat Hossain Shuhan</p>
        </div>
      </div>
    </motion.div>
  );
}

function SettingItem({ icon, label, value, onClick, toggle, danger }: any) {
  const [isToggled, setIsToggled] = useState(false);
  
  return (
    <GlassCard 
      onClick={onClick}
      className={cn(
        "p-4 flex items-center justify-between cursor-pointer active:scale-[0.98] transition-all",
         danger && "border-red-500/10"
      )}
    >
      <div className="flex items-center gap-4">
        <div className="p-2 rounded-lg bg-white/5">{icon}</div>
        <span className={cn("text-sm font-medium", danger ? "text-red-400" : "text-white/80")}>{label}</span>
      </div>
      
      {toggle ? (
        <button onClick={(e) => { e.stopPropagation(); setIsToggled(!isToggled); }} className={cn("w-10 h-6 rounded-full p-1 transition-all", isToggled ? "bg-neon-cyan" : "bg-white/10")}>
           <div className={cn("w-4 h-4 rounded-full bg-white transition-all", isToggled ? "translate-x-4" : "translate-x-0")} />
        </button>
      ) : value ? (
        <span className="text-xs text-white/40">{value}</span>
      ) : (
        <ChevronRight size={16} className="text-white/20" />
      )}
    </GlassCard>
  );
}
