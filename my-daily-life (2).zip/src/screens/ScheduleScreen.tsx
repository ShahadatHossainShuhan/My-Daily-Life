import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, X, Calendar as CalIcon, BookOpen, Bell, Trash2, Clock, MapPin, ChevronLeft, ChevronRight, GraduationCap } from 'lucide-react';
import { GlassCard, NeonButton } from '../components/ui/Common';
import { dbService, type ScheduleItem, type AcademicRecord } from '../lib/db';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addMonths, subMonths, startOfWeek, endOfWeek, isAfter } from 'date-fns';
import { cn } from '../lib/utils';
import { translations } from '../lib/i18n';

export default function ScheduleScreen({ language }: { language: string, key?: string }) {
  const [activeTab, setActiveTab] = useState<'weekly' | 'academic' | 'calendar'>('weekly');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'class' | 'academic'>('class');

  // Multi-tab state
  const [schedules, setSchedules] = useState<ScheduleItem[]>([]);
  const [academics, setAcademics] = useState<AcademicRecord[]>([]);
  
  // Calendar state
  const [currentMonth, setCurrentMonth] = useState(startOfMonth(new Date()));
  const [selectedDate, setSelectedDate] = useState(new Date());

  const t = translations[language];

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    const s = await dbService.getAll('schedules');
    const a = await dbService.getAll('academic');
    setSchedules(s);
    setAcademics(a);
  }

  const handleDelete = async (store: 'schedules' | 'academic', id: string | undefined) => {
    if (!id) return;
    await dbService.delete(store, id);
    loadData();
  };

  const filteredAcademics = academics.filter(item => {
    const eventDate = new Date(item.date);
    const [hours, minutes] = (item.time || '00:00').split(':');
    eventDate.setHours(parseInt(hours), parseInt(minutes));
    return isAfter(eventDate, new Date());
  });

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">{t.schedule}</h1>
      </div>

      {/* Internal Tabs */}
      <div className="flex p-1 bg-white/5 rounded-2xl gap-1">
        {(['weekly', 'academic', 'calendar'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={cn(
              "flex-1 py-3 rounded-xl text-[10px] uppercase font-bold tracking-widest transition-all",
              activeTab === tab ? "bg-white/10 text-neon-cyan shadow-lg" : "text-white/40 hover:text-white"
            )}
          >
            {t[tab] || tab}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'weekly' && <WeeklyTab key="weekly" schedules={schedules} onDelete={(id) => handleDelete('schedules', id)} language={language} translations={t} />}
        {activeTab === 'academic' && <AcademicTab key="academic" academics={academics} onDelete={(id) => handleDelete('academic', id)} language={language} translations={t} />}
        {activeTab === 'calendar' && (
          <CalendarTab 
            key="calendar" 
            schedules={schedules} 
            academics={academics} 
            currentMonth={currentMonth} 
            setCurrentMonth={setCurrentMonth}
            selectedDate={selectedDate}
            setSelectedDate={setSelectedDate}
            language={language}
            translations={t}
          />
        )}
      </AnimatePresence>

      {/* FAB */}
      {activeTab !== 'calendar' && (
        <motion.button
          whileHover={{ scale: 1.1, rotate: 90 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => {
            setModalType(activeTab === 'weekly' ? 'class' : 'academic');
            setIsModalOpen(true);
          }}
          className="fixed bottom-28 right-8 w-14 h-14 bg-neon-cyan text-navy-black rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(0,242,255,0.5)] z-40"
        >
          <Plus size={28} />
        </motion.button>
      )}

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsModalOpen(false)} className="absolute inset-0 bg-navy-black/80 backdrop-blur-md" />
            <motion.div initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 20 }} className="glass-card w-full max-w-sm p-8 relative z-10 border-white/20 shadow-2xl">
              <AddModalContent type={modalType} language={language} t={t} onClose={() => { setIsModalOpen(false); loadData(); }} />
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function WeeklyTab({ schedules, onDelete, language, translations: t }: any) {
  const engDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  
  return (
    <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} className="space-y-6">
      {engDays.map((engDay) => {
        const dayClasses = schedules.filter((s: any) => s.day === engDay);
        if (dayClasses.length === 0) return null;
        
        return (
          <div key={engDay} className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-neon-cyan ml-1">{t.days[engDay]}</h3>
            {dayClasses.map((item: any) => (
              <div key={item.id}>
                <GlassCard className="p-4 flex items-center gap-4 group hover:border-white/30 transition-all">
                  <div className="w-12 h-12 rounded-xl bg-neon-blue/10 text-neon-blue border border-neon-blue/20 flex items-center justify-center shadow-lg transition-all">
                    <Clock size={20} />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-sm text-white/90">{item.subject}</h4>
                    <div className="flex items-center gap-3 mt-1.5">
                      <span className="text-[10px] text-white/40 flex items-center gap-1.5 font-medium"><Clock size={12} className="text-neon-cyan/50" /> {item.time}</span>
                      <span className="text-[10px] text-white/40 flex items-center gap-1.5 font-medium"><MapPin size={12} className="text-neon-cyan/50" /> {item.room}</span>
                    </div>
                  </div>
                  <button onClick={() => onDelete(item.id)} className="opacity-0 group-hover:opacity-100 text-white/20 hover:text-red-500 transition-all p-1">
                    <Trash2 size={16} />
                  </button>
                </GlassCard>
              </div>
            ))}
          </div>
        );
      })}
      {schedules.length === 0 && (
        <div className="py-20 text-center bg-white/[0.02] border border-white/5 rounded-[2rem]">
          <p className="text-white/20 italic text-sm">{t.noClasses}</p>
        </div>
      )}
    </motion.div>
  );
}

function AcademicTab({ academics, onDelete, language, translations: t }: any) {
  const now = new Date();
  const upcoming = academics.filter((item: any) => {
    const eventDate = new Date(item.date);
    const [hours, minutes] = (item.time || '00:00').split(':');
    eventDate.setHours(parseInt(hours), parseInt(minutes));
    return isAfter(eventDate, now);
  }).sort((a: any, b: any) => a.date.getTime() - b.date.getTime());

  const history = academics.filter((item: any) => {
    const eventDate = new Date(item.date);
    const [hours, minutes] = (item.time || '00:00').split(':');
    eventDate.setHours(parseInt(hours), parseInt(minutes));
    return !isAfter(eventDate, now);
  }).sort((a: any, b: any) => b.date.getTime() - a.date.getTime());

  return (
    <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} className="space-y-8 pb-20">
      {/* Upcoming Section */}
      <div className="space-y-4">
        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-neon-cyan ml-1">{language === 'English' ? 'Upcoming' : 'আসন্ন'}</h3>
        {upcoming.length > 0 ? upcoming.map((item: any, i: number) => (
          <AcademicCard key={item.id} item={item} i={i} t={t} language={language} onDelete={onDelete} />
        )) : (
          <div className="py-12 text-center bg-white/[0.02] border border-white/5 rounded-[2rem]">
            <p className="text-white/20 italic text-xs tracking-widest uppercase">{t.noUpcoming}</p>
          </div>
        )}
      </div>

      {/* History Section */}
      {history.length > 0 && (
        <div className="space-y-4 pt-4 border-t border-white/5">
          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-white/20 ml-1">{language === 'English' ? 'History' : 'ইতিহাস'}</h3>
          <div className="opacity-60 grayscale-[0.5]">
            {history.map((item: any, i: number) => (
              <div key={item.id} className="mb-3 last:mb-0">
                <AcademicCard item={item} i={i} t={t} language={language} onDelete={onDelete} />
              </div>
            ))}
          </div>
        </div>
      )}

      {academics.length === 0 && (
        <div className="py-20 text-center bg-white/[0.02] border border-white/5 rounded-[2rem]">
          <p className="text-white/20 italic text-sm">{t.noRecordsFound}</p>
        </div>
      )}
    </motion.div>
  );
}

function AcademicCard({ item, i, t, language, onDelete }: any) {
  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
      <GlassCard className="p-4 flex items-center gap-4 relative overflow-hidden group hover:border-white/30 transition-all">
        <div className={cn(
           "absolute left-0 top-0 bottom-0 w-1",
           item.type === 'task' ? "bg-neon-cyan shadow-[0_0_10px_#22d3ee]" : item.type === 'exam' ? "bg-neon-pink shadow-[0_0_10px_#f43f5e]" : "bg-neon-blue shadow-[0_0_10px_#3b82f6]"
        )} />
        <div className={cn(
          "w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-300",
          item.type === 'task' ? "bg-neon-cyan/10 text-neon-cyan border border-neon-cyan/20" : item.type === 'exam' ? "bg-neon-pink/10 text-neon-pink border border-neon-pink/20" : "bg-neon-blue/10 text-neon-blue border border-neon-blue/20"
        )}>
          <GraduationCap size={20} />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h4 className="font-bold text-sm text-white/90">{item.title}</h4>
            <span className={cn(
              "text-[8px] uppercase px-1.5 py-0.5 rounded-full border leading-none font-black tracking-tighter",
              item.type === 'task' ? "border-neon-cyan text-neon-cyan" : item.type === 'exam' ? "border-neon-pink text-neon-pink" : "border-neon-blue text-neon-blue"
            )}>{(t[item.type])}</span>
          </div>
          <div className="flex items-center gap-3 mt-1.5">
            <span className="text-[10px] text-white/40 font-medium tracking-wide uppercase">{format(item.date, language === 'English' ? 'MMM dd' : 'dd MMM')} • {item.time}</span>
            {item.alarm && <Bell size={10} className="text-neon-cyan animate-pulse" />}
          </div>
        </div>
        <button onClick={() => onDelete(item.id)} className="opacity-0 group-hover:opacity-100 text-white/20 hover:text-red-500 transition-all p-1">
          <Trash2 size={16} />
        </button>
      </GlassCard>
    </motion.div>
  );
}

function CalendarTab({ schedules, academics, currentMonth, setCurrentMonth, selectedDate, setSelectedDate, language, translations: t }: any) {
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart);
  const endDate = endOfWeek(monthEnd);
  
  const days = eachDayOfInterval({ start: startDate, end: endDate });
  
  const selectedDayItems = [
    ...academics.filter((a: any) => isSameDay(a.date, selectedDate)).map((a: any) => ({ ...a, eventType: 'academic' })),
    ...schedules.filter((s: any) => s.day === format(selectedDate, 'EEEE')).map((s: any) => ({ ...s, eventType: 'class' }))
  ].sort((a, b) => (a.time || '00:00').localeCompare(b.time || '00:00'));

  const nextMonth = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentMonth(prev => addMonths(startOfMonth(prev), 1));
  };
  const prevMonth = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentMonth(prev => subMonths(startOfMonth(prev), 1));
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      exit={{ opacity: 0, y: 20 }} 
      className="space-y-6"
    >
      <GlassCard className="p-6 bg-white/[0.03] border-white/10 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-neon-cyan/5 blur-[50px] -mr-16 -mt-16" />
        
        <div className="flex justify-between items-center mb-8 px-1">
          <div>
            <h3 className="font-extrabold text-lg uppercase tracking-[0.2em] font-display bg-gradient-to-r from-white to-white/40 bg-clip-text text-transparent">
              {format(currentMonth, 'MMMM')}
            </h3>
            <p className="text-[10px] font-black text-neon-cyan/60 tracking-[0.4em] uppercase mt-1">{format(currentMonth, 'yyyy')}</p>
          </div>
          <div className="flex gap-2 bg-white/5 p-1.5 rounded-2xl border border-white/5 relative z-20">
            <button 
              type="button"
              onClick={prevMonth} 
              className="p-3 hover:bg-white/10 rounded-xl text-white/40 hover:text-neon-cyan active:scale-95 transition-all cursor-pointer"
              aria-label="Previous Month"
            >
              <ChevronLeft size={20} />
            </button>
            <button 
              type="button"
              onClick={nextMonth} 
              className="p-3 hover:bg-white/10 rounded-xl text-white/40 hover:text-neon-cyan active:scale-95 transition-all cursor-pointer"
              aria-label="Next Month"
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-7 mb-4">
          {(language === 'English' ? ['S', 'M', 'T', 'W', 'T', 'F', 'S'] : ['র', 'সো', 'ম', 'বু', 'বৃ', 'শু', 'শ']).map((d, i) => (
            <div key={`${d}-${i}`} className="text-center text-[9px] font-black text-white/20 p-2 uppercase tracking-widest">{d}</div>
          ))}
        </div>
        
        <div className="grid grid-cols-7 gap-1">
          {days.map((day, i) => {
            const isSelected = isSameDay(day, selectedDate);
            const isCurrentMonth = isSameDay(startOfMonth(day), monthStart);
            const isToday = isSameDay(day, new Date());
            const items = [
              ...academics.filter((a: any) => isSameDay(a.date, day)),
              ...schedules.filter((s: any) => s.day === format(day, 'EEEE'))
            ];

            return (
              <button
                key={i}
                onClick={() => setSelectedDate(day)}
                className={cn(
                  "aspect-square rounded-2xl flex flex-col items-center justify-center transition-all duration-300 relative group",
                  isSelected ? "bg-neon-cyan/20 ring-1 ring-neon-cyan/50 shadow-[0_0_20px_rgba(34,211,238,0.25)] scale-105 z-10" : "hover:bg-white/10",
                  !isCurrentMonth && "opacity-[0.08]"
                )}
              >
                <span className={cn(
                  "text-xs font-bold relative z-10 transition-colors",
                  isSelected ? "text-white" : isToday ? "text-neon-cyan" : "text-white/60 group-hover:text-white"
                )}>
                  {format(day, 'd')}
                </span>
                
                {/* Event Indicators */}
                {items.length > 0 && isCurrentMonth && (
                  <div className="absolute bottom-2 flex gap-0.5">
                    {Array.from(new Set(items.map(it => (it as any).type || 'class'))).slice(0, 3).map((type, idx) => (
                      <div 
                        key={idx} 
                        className={cn(
                          "w-1 h-1 rounded-full shadow-[0_0_5px_currentColor]",
                          type === 'class' || (type as any) === 'class' ? "bg-neon-blue text-neon-blue" : 
                          type === 'task' ? "bg-neon-cyan text-neon-cyan" : "bg-neon-pink text-neon-pink"
                        )} 
                      />
                    ))}
                  </div>
                )}
                
                {isToday && !isSelected && (
                   <div className="absolute top-1.5 right-1.5 w-1 h-1 bg-neon-cyan rounded-full shadow-[0_0_5px_#22d3ee]" />
                )}
              </button>
            );
          })}
        </div>
      </GlassCard>

      <div className="space-y-4 px-1">
        <div className="flex justify-between items-end mb-2">
          <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-white/30">
            {format(selectedDate, 'EEEE, MMM dd')}
          </h4>
          <span className="text-[9px] font-bold text-neon-cyan uppercase tracking-tighter opacity-60">
            {selectedDayItems.length} {t.events}
          </span>
        </div>
        
        <div className="space-y-3">
          <AnimatePresence mode="popLayout">
            {selectedDayItems.map((item, i) => (
              <motion.div 
                key={item.id || i} 
                initial={{ opacity: 0, x: -10 }} 
                animate={{ opacity: 1, x: 0 }} 
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ delay: i * 0.05 }}
              >
                <GlassCard className="p-5 flex items-center gap-5 group hover:border-white/30 transition-all active:scale-[0.98] rounded-3xl bg-white/[0.02]">
                  <div className={cn(
                    "w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg transition-all duration-500 group-hover:rotate-6",
                    item.eventType === 'class' ? "bg-neon-blue/10 text-neon-blue border border-neon-blue/20" : 
                    item.type === 'task' ? "bg-neon-cyan/10 text-neon-cyan border border-neon-cyan/20" :
                    "bg-neon-pink/10 text-neon-pink border border-neon-pink/20"
                  )}>
                    {item.eventType === 'class' ? <BookOpen size={20} /> : <GraduationCap size={20} />}
                  </div>
                  <div className="flex-1">
                    <h5 className="font-bold text-sm text-white underline decoration-transparent group-hover:decoration-current transition-all">
                      {item.subject || item.title}
                    </h5>
                    <div className="flex items-center gap-3 mt-2">
                      <div className="flex items-center gap-1.5">
                        <Clock size={12} className="text-white/20" />
                        <span className="text-[10px] text-white/40 font-bold tabular-nums">{item.time}</span>
                      </div>
                      <span className="w-1 h-1 rounded-full bg-white/5" />
                      <div className="flex items-center gap-1.5">
                        <MapPin size={12} className="text-white/20" />
                        <span className="text-[10px] text-white/40 font-bold truncate max-w-[100px]">
                          {item.room || item.description || t.mainHall}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white/5 p-2 rounded-xl group-hover:bg-neon-cyan/10 transition-colors">
                    <ChevronRight size={14} className="text-white/20 group-hover:text-neon-cyan" />
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </AnimatePresence>

          {selectedDayItems.length === 0 && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }}
              className="py-16 text-center bg-white/[0.01] border border-dashed border-white/5 rounded-[2.5rem] group"
            >
              <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <CalIcon size={20} className="text-white/10" />
              </div>
              <p className="text-white/20 italic text-[10px] uppercase font-black tracking-[0.2em]">
                {t.restDay}
              </p>
            </motion.div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

function AddModalContent({ type, onClose, language, t }: any) {
  const [formData, setFormData] = useState<any>({
    title: '', day: 'Monday', subject: '', time: '09:00', room: '', repeat: true, type: 'task', alarm: true, date: format(new Date(), 'yyyy-MM-dd')
  });

  const handleSave = async () => {
    if (!formData.subject && !formData.title) return;
    if (type === 'class') {
      await dbService.add('schedules', {
        day: formData.day, subject: formData.subject, time: formData.time, room: formData.room, repeat: formData.repeat
      });
    } else {
      await dbService.add('academic', {
        type: formData.type, title: formData.title, date: new Date(formData.date), time: formData.time, room: formData.room, alarm: formData.alarm
      });
    }
    onClose();
  };

  return (
    <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-bold">{type === 'class' ? t.addClass : t.addRecord}</h3>
          <button onClick={onClose} className="text-white/40 hover:text-white transition-colors"><X size={24} /></button>
        </div>
       
       {type === 'class' ? (
         <div className="space-y-4">
           <Input label={t.subject} value={formData.subject} onChange={(v: string) => setFormData({...formData, subject: v})} />
           <div className="grid grid-cols-2 gap-4">
             <Select label={t.day} value={formData.day} options={['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']} labels={t.days} onChange={(v: string) => setFormData({...formData, day: v})} />
             <Input label={t.time} type="time" value={formData.time} onChange={(v: string) => setFormData({...formData, time: v})} />
           </div>
           <Input label={t.room} value={formData.room} onChange={(v: string) => setFormData({...formData, room: v})} />
         </div>
       ) : (
         <div className="space-y-4">
           <div className="flex p-1 bg-white/5 rounded-2xl gap-1">
             {['task', 'exam', 'notice'].map(tk => (
               <button key={tk} onClick={() => setFormData({...formData, type: tk})} className={cn("flex-1 py-2.5 rounded-xl text-[9px] uppercase font-bold tracking-widest transition-all", formData.type === tk ? "bg-white/10 text-neon-cyan shadow-sm" : "text-white/20")}>
                 {t[tk]}
               </button>
             ))}
           </div>
           <Input label={t.title} value={formData.title} onChange={(v: string) => setFormData({...formData, title: v})} />
           <div className="grid grid-cols-2 gap-4">
             <Input label={t.date} type="date" value={formData.date} onChange={(v: string) => setFormData({...formData, date: v})} />
             <Input label={t.time} type="time" value={formData.time} onChange={(v: string) => setFormData({...formData, time: v})} />
           </div>
           <Input label={t.location} value={formData.room} onChange={(v: string) => setFormData({...formData, room: v})} />
           <div className="flex items-center justify-between px-2 py-1">
             <span className="text-[10px] uppercase font-bold tracking-widest text-white/40">{t.setAlarm}</span>
             <button onClick={() => setFormData({...formData, alarm: !formData.alarm})} className={cn("w-10 h-5 rounded-full p-0.5 transition-all outline-none", formData.alarm ? "bg-neon-cyan" : "bg-white/10")}>
               <div className={cn("w-4 h-4 rounded-full bg-white shadow-sm transition-all", formData.alarm ? "translate-x-5" : "translate-x-0")} />
             </button>
           </div>
         </div>
       )}
       
        <NeonButton onClick={handleSave} className="w-full py-4 text-sm font-bold uppercase tracking-widest">
          {t.saveRecord}
        </NeonButton>
    </div>
  );
}

function Input({ label, value, onChange, type = 'text' }: any) {
  return (
    <div className="space-y-2">
      <label className="text-[10px] uppercase font-bold tracking-widest text-white/40 ml-1">{label}</label>
      <input type={type} value={value} onChange={e => onChange(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-3 outline-none focus:border-neon-cyan transition-all text-sm font-medium text-white placeholder:text-white/10" />
    </div>
  );
}

function Select({ label, value, options, labels, onChange }: any) {
  return (
    <div className="space-y-2">
      <label className="text-[10px] uppercase font-bold tracking-widest text-white/40 ml-1">{label}</label>
      <select value={value} onChange={e => onChange(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-3 outline-none focus:border-neon-cyan transition-all text-sm font-medium text-white appearance-none">
        {options.map((o: any) => <option key={o} value={o} className="bg-navy-black text-white">{labels && labels[o] ? labels[o] : o}</option>)}
      </select>
    </div>
  );
}
