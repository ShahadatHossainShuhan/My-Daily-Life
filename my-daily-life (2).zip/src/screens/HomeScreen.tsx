import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Bell, CreditCard, TrendingUp, TrendingDown, Clock, BellRing, User, Calendar } from 'lucide-react';
import { GlassCard, NeonButton } from '../components/ui/Common';
import { dbService, type Transaction, type AcademicRecord, type ScheduleItem, type UserProfile } from '../lib/db';
import { format, isAfter } from 'date-fns';
import { cn } from '../lib/utils';
import { translations } from '../lib/i18n';

export default function HomeScreen({ profile, language, onTabChange }: { profile: UserProfile | null, language: string, onTabChange: (tab: string) => void, key?: string }) {
  const [greeting, setGreeting] = useState('');
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [upcoming, setUpcoming] = useState<any[]>([]);
  
  const t = translations[language];

  useEffect(() => {
    const hour = new Date().getHours();
    if (hour < 12) setGreeting(`${t.goodMorning} 🌅`);
    else if (hour < 18) setGreeting(`${t.goodAfternoon} ☀️`);
    else setGreeting(`${t.goodEvening} 🌙`);

    async function loadData() {
      const txs = await dbService.getAll('transactions');
      
      // Grouping logic: same title, same date, same type
      const groups: { [key: string]: Transaction } = {};
      txs.forEach(tx => {
        const dateStr = format(tx.date, 'yyyy-MM-dd');
        const key = `${tx.title.toLowerCase().trim()}-${dateStr}-${tx.type}`;
        if (groups[key]) {
          groups[key].amount += tx.amount;
        } else {
          groups[key] = { ...tx };
        }
      });
      const groupedTxs = Object.values(groups).sort((a, b) => b.date.getTime() - a.date.getTime());
      setTransactions(groupedTxs);

      // Get upcoming events
      const academic = await dbService.getAll('academic');
      const schedules = await dbService.getAll('schedules');
      
      const now = new Date();
      const filteredAcademic = academic.filter(item => {
        const eventDate = new Date(item.date);
        const [hours, minutes] = (item.time || '00:00').split(':');
        eventDate.setHours(parseInt(hours), parseInt(minutes));
        return isAfter(eventDate, now);
      });
      
      const combinedUpcoming = [
        ...filteredAcademic.map(a => ({ ...a, eventType: 'academic' })),
        ...schedules.filter(s => s.day === format(new Date(), 'EEEE')).map(s => ({ ...s, eventType: 'class' }))
      ].sort((a, b) => {
        const timeA = (a as any).time || '00:00';
        const timeB = (b as any).time || '00:00';
        return timeA.localeCompare(timeB);
      }).slice(0, 3);
      
      setUpcoming(combinedUpcoming);
    }
    loadData();
  }, [language]);

  const financialSummary = transactions.reduce((acc, tx) => {
    if (tx.type === 'income') acc.income += tx.amount;
    else acc.spent += tx.amount;
    return acc;
  }, { income: 0, spent: 0 }); // Removed dummy 5000 income

  const balance = financialSummary.income - financialSummary.spent;

  const healthPercent = financialSummary.income > 0 
    ? Math.min(100, Math.max(0, (balance / financialSummary.income) * 100))
    : (balance > 0 ? 100 : 0);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="space-y-6 pt-2"
    >
      {/* Header Section */}
      <div className="px-2 flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-semibold leading-tight text-white">
            {greeting},<br />
            <span className="text-neon-cyan flex items-center gap-2">
              {profile?.name || 'Explorer'} <span className="text-neon-pink">❤️</span>
            </span>
          </h1>
        </div>
        <div className="w-12 h-12 rounded-2xl border-2 border-neon-cyan/30 overflow-hidden shadow-[0_0_15px_rgba(34,211,238,0.2)]">
          {profile?.avatar ? (
            <img src={profile.avatar} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-neon-cyan to-neon-blue flex items-center justify-center font-bold">
              {profile?.name?.charAt(0) || 'U'}
            </div>
          )}
        </div>
      </div>

      <div className="space-y-6 overflow-hidden">
        {/* Financial Summary Card */}
        <GlassCard className="p-5 bg-white/5 backdrop-blur-2xl border-white/10 rounded-3xl relative overflow-hidden">
          <div className="absolute -top-10 -right-10 w-24 h-24 bg-neon-cyan/10 blur-3xl" />
          
          <div className="flex justify-between items-start mb-4">
            <span className="text-[10px] uppercase tracking-[0.2em] font-bold text-white/30 flex items-center gap-2">
              {t.usableBalance} <span className="text-neon-cyan animate-pulse">✨</span>
            </span>
            <span className={cn(
              "text-xs font-mono font-bold tracking-tighter",
              balance > 0 ? "text-neon-cyan" : "text-neon-pink"
            )}>
              {balance > 0 ? t.surplus : t.deficit}
            </span>
          </div>
          <h2 className="text-3xl font-bold mb-6 text-white tracking-tight">
            {t.currencySymbol}{balance.toLocaleString()}
          </h2>
          
          <div className="space-y-4">
            <div className="flex justify-between text-[11px] font-medium">
              <span className="text-white/60">{t.financialHealth}</span>
              <span className={cn(
                healthPercent > 70 ? "text-neon-cyan" : 
                healthPercent > 40 ? "text-orange-400" : "text-neon-pink"
              )}>
                {healthPercent > 70 ? t.excellent : healthPercent > 40 ? t.fair : t.critical} ({Math.round(healthPercent)}%)
              </span>
            </div>
            <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${healthPercent}%` }}
                transition={{ duration: 1.5, ease: "easeOut" }}
                className={cn(
                  "h-full rounded-full shadow-[0_0_10px_rgba(34,211,238,0.8)]",
                  healthPercent > 70 ? "bg-neon-cyan" : healthPercent > 40 ? "bg-orange-400" : "bg-neon-pink"
                )}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="bg-white/5 rounded-xl p-3">
                <p className="text-[9px] text-white/40 uppercase mb-1">{t.income}</p>
                <p className="text-sm font-bold text-neon-cyan">{t.currencySymbol}{financialSummary.income.toLocaleString()}</p>
              </div>
              <div className="bg-white/5 rounded-xl p-3">
                <p className="text-[9px] text-white/40 uppercase mb-1">{t.spent}</p>
                <p className="text-sm font-bold text-white/80">{t.currencySymbol}{financialSummary.spent.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </GlassCard>

        {/* Upcoming Section */}
        <div>
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-sm font-bold uppercase tracking-widest">{t.upcoming}</h3>
            <span 
              onClick={() => onTabChange('schedule')}
              className="text-[10px] text-neon-cyan underline decoration-neon-cyan/30 cursor-pointer hover:text-white transition-colors"
            >
              {t.viewAll}
            </span>
          </div>
          
          <div className="space-y-3">
            {upcoming.length > 0 ? upcoming.map((item, i) => (
              <div key={i}>
                <div className="group bg-white/5 backdrop-blur-md border border-white/5 rounded-2xl p-4 flex items-center gap-4">
                  <div className={cn(
                    "w-10 h-10 rounded-xl flex flex-col items-center justify-center border",
                    item.eventType === 'class' ? "bg-neon-blue/10 border-neon-blue/20 text-neon-blue" : "bg-neon-pink/10 border-neon-pink/20 text-neon-pink"
                  )}>
                    <span className="text-[9px] font-bold uppercase">{format(new Date(), 'MMM')}</span>
                    <span className="text-xs font-black">{format(new Date(), 'dd')}</span>
                  </div>
                  <div className="flex-1">
                    <p className="text-xs font-bold text-white/90">{item.subject || item.title}</p>
                    <p className="text-[10px] text-white/40">{item.room ? `${t.room} ${item.room}` : t.mainHall} • {item.time}</p>
                  </div>
                  <div className="w-2 h-2 rounded-full bg-neon-cyan shadow-[0_0_5px_rgba(34,211,238,1)]" />
                </div>
              </div>
            )) : (
              <div className="py-8 text-center text-white/20 italic text-xs">{t.noUpcoming}</div>
            )}
          </div>
        </div>
      </div>

      {/* Recent History */}
      <div className="space-y-4 pb-12">
        <h3 className="text-sm font-bold uppercase tracking-widest px-1">{t.recentActivity}</h3>
        <div className="space-y-3">
          {transactions.slice(0, 3).map((tx, i) => (
            <div key={tx.id || i}>
              <div className="bg-white/5 backdrop-blur-md border border-white/5 rounded-2xl p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "p-2 rounded-lg",
                    tx.type === 'income' ? "bg-neon-cyan/10 text-neon-cyan" : "bg-neon-pink/10 text-neon-pink"
                  )}>
                    {tx.type === 'income' ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
                  </div>
                  <div>
                    <h4 className="font-medium text-xs text-white/90">{tx.title}</h4>
                    <p className="text-[9px] text-white/30 uppercase tracking-widest">{format(tx.date, 'MMM dd, yyyy')}</p>
                  </div>
                </div>
                <div className={cn(
                  "font-bold text-sm",
                  tx.type === 'income' ? "text-neon-cyan" : "text-neon-pink"
                )}>
                  {tx.type === 'income' ? '+' : '-'}{t.currencySymbol}{tx.amount}
                </div>
              </div>
            </div>
          ))}
          {transactions.length > 0 && (
            <button 
              onClick={() => onTabChange('expenses')}
              className="w-full py-3 rounded-2xl border border-dashed border-white/10 text-[10px] uppercase font-bold text-white/30 hover:text-neon-cyan hover:border-neon-cyan/30 transition-all"
            >
              {language === 'English' ? 'See Full Financial History' : 'সম্পূর্ণ আর্থিক ইতিহাস দেখুন'}
            </button>
          )}
          {transactions.length === 0 && (
            <div className="py-8 text-center text-white/20 italic text-xs">{t.noRecent}</div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
