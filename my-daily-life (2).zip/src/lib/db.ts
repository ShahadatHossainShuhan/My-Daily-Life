import { openDB, type DBSchema, type IDBPDatabase } from 'idb';

export interface Transaction {
  id?: string;
  title: string;
  amount: number;
  type: 'income' | 'expense';
  date: Date;
  category?: string;
}

export interface ScheduleItem {
  id?: string;
  day: string; // 'Monday', 'Tuesday', etc.
  subject: string;
  time: string;
  room: string;
  repeat: boolean;
}

export interface AcademicRecord {
  id?: string;
  type: 'task' | 'exam' | 'notice';
  title: string;
  date: Date;
  time: string;
  room: string;
  alarm: boolean;
}

export interface UserProfile {
  name: string;
  email: string;
  avatar: string;
}

export interface AppSettings {
  language: string;
  pin: string | null;
  notificationsEnabled: boolean;
  alarmPermission: boolean;
}

interface MyDB extends DBSchema {
  transactions: {
    key: string;
    value: Transaction;
    index: { 'by-date': Date };
  };
  schedules: {
    key: string;
    value: ScheduleItem;
    index: { 'by-day': string };
  };
  academic: {
    key: string;
    value: AcademicRecord;
    index: { 'by-date': Date };
  };
  profile: {
    key: string;
    value: UserProfile;
  };
  settings: {
    key: string;
    value: any;
  };
}

const DB_NAME = 'my-daily-life-db';
const DB_VERSION = 1;

export async function initDB(): Promise<IDBPDatabase<MyDB>> {
  return openDB<MyDB>(DB_NAME, DB_VERSION, {
    upgrade(db) {
      // Transactions
      if (!db.objectStoreNames.contains('transactions')) {
        const txStore = db.createObjectStore('transactions', { keyPath: 'id' });
        (txStore as any).createIndex('by-date', 'date');
      }

      // Schedules
      if (!db.objectStoreNames.contains('schedules')) {
        const schStore = db.createObjectStore('schedules', { keyPath: 'id' });
        (schStore as any).createIndex('by-day', 'day');
      }

      // Academic
      if (!db.objectStoreNames.contains('academic')) {
        const acadStore = db.createObjectStore('academic', { keyPath: 'id' });
        (acadStore as any).createIndex('by-date', 'date');
      }

      // Profile
      if (!db.objectStoreNames.contains('profile')) {
        db.createObjectStore('profile');
      }

      // Settings
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings');
      }
    },
  });
}

export const dbService = {
  async getAll<T extends 'transactions' | 'schedules' | 'academic'>(storeName: T) {
    const db = await initDB();
    return db.getAll(storeName);
  },
  async add<T extends 'transactions' | 'schedules' | 'academic'>(storeName: T, value: any) {
    const db = await initDB();
    const id = crypto.randomUUID();
    await db.put(storeName, { ...value, id });
    return id;
  },
  async delete<T extends 'transactions' | 'schedules' | 'academic'>(storeName: T, id: string) {
    const db = await initDB();
    return db.delete(storeName, id);
  },
  async saveProfile(profile: UserProfile) {
    const db = await initDB();
    return db.put('profile', profile, 'user');
  },
  async getProfile(): Promise<UserProfile | undefined> {
    const db = await initDB();
    return db.get('profile', 'user');
  },
  async saveSetting(key: string, value: any) {
    const db = await initDB();
    return db.put('settings', value, key);
  },
  async getSetting(key: string) {
    const db = await initDB();
    return db.get('settings', key);
  }
};
