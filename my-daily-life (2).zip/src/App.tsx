import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Home, Landmark, Calendar, User, Plus } from 'lucide-react';
import { cn } from './lib/utils';
import HomeScreen from './screens/HomeScreen';
import ExpenseScreen from './screens/ExpenseScreen';
import ScheduleScreen from './screens/ScheduleScreen';
import ProfileScreen from './screens/ProfileScreen';
import { dbService, type UserProfile } from './lib/db';
import { translations } from './lib/i18n';
import { format, isSameDay } from 'date-fns';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [user, setUser] = useState<UserProfile | null>(null);
  const [language, setLanguage] = useState('English');
  const [isLocked, setIsLocked] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [correctPin, setCorrectPin] = useState<string | null>(null);

  const t = translations[language];

  useEffect(() => {
    async function loadData() {
      const profile = await dbService.getProfile();
      if (profile) {
        setUser(profile);
      } else {
        const defaultProfile = { name: 'Guest User', email: 'guest@example.com', avatar: 'https://avatar.iran.liara.run/public/boy' };
        await dbService.saveProfile(defaultProfile);
        setUser(defaultProfile);
      }
      
      const lang = await dbService.getSetting('language');
      if (lang) setLanguage(lang);

      const pin = await dbService.getSetting('appLockPin');
      if (pin) {
        setCorrectPin(pin);
        setIsLocked(true);
      }
    }
    loadData();
  }, []);

  // Notification Checker Logic
  useEffect(() => {
    const checkSchedule = async () => {
      if (Notification.permission !== 'granted') return;

      const schedules = await dbService.getAll('schedules');
      const academic = await dbService.getAll('academic');
      const now = new Date();
      const currentDay = format(now, 'EEEE');
      
      const tenMinutesLater = new Date(now.getTime() + 10 * 60000);
      const targetTime = format(tenMinutesLater, 'HH:mm');

      // Check regular classes
      const upcomingClass = schedules.find(s => s.day === currentDay && s.time === targetTime);
      if (upcomingClass) {
        new Notification(language === 'English' ? "Upcoming Class!" : "আসন্ন ক্লাস!", {
          body: language === 'English' 
            ? `${upcomingClass.subject} starts in 10 mins at room ${upcomingClass.room}`
            : `${upcomingClass.subject} ১০ মিনিটের মধ্যে শুরু হবে, রুম: ${upcomingClass.room}`,
          icon: '/pwa-192x192.png'
        });
      }

      // Check academic events (exams/tasks)
      const upcomingAcademic = academic.find(a => {
        if (!a.alarm) return false;
        return isSameDay(a.date, now) && a.time === targetTime;
      });

      if (upcomingAcademic) {
        const typeLabel = language === 'English' ? upcomingAcademic.type : (upcomingAcademic.type === 'task' ? 'কাজ' : upcomingAcademic.type === 'exam' ? 'পরীক্ষা' : 'নোটিশ');
        new Notification(language === 'English' ? `Upcoming ${typeLabel}!` : `আসন্ন ${typeLabel}!`, {
          body: language === 'English'
            ? `${upcomingAcademic.title} starts in 10 mins`
            : `${upcomingAcademic.title} ১০ মিনিটের মধ্যে শুরু হবে`,
          icon: '/pwa-192x192.png'
        });
      }
    };

    const interval = setInterval(checkSchedule, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [language]);

  const handleUnlock = () => {
    if (pinInput === correctPin) {
      setIsLocked(false);
      setPinInput('');
    } else {
      setPinInput('');
      alert(t.incorrectPin);
    }
  };

  const renderScreen = () => {
    switch (activeTab) {
      case 'home': return <HomeScreen key="home" profile={user} language={language} onTabChange={setActiveTab} />;
      case 'expenses': return <ExpenseScreen key="expenses" language={language} />;
      case 'schedule': return <ScheduleScreen key="schedule" language={language} />;
      case 'profile': return user ? (
        <ProfileScreen 
          key="profile" 
          user={user} 
          onUpdateUser={setUser} 
          language={language} 
          onLanguageChange={setLanguage} 
        />
      ) : null;
      default: return <HomeScreen key="home" profile={user} language={language} onTabChange={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen pb-24 text-white selection:bg-neon-cyan/30 relative bg-[#020617]">
      <AnimatePresence>
        {isLocked && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }} 
            className="fixed inset-0 z-[1000] bg-navy-black flex flex-col items-center justify-center p-6 backdrop-blur-3xl"
          >
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-neon-cyan to-neon-blue p-0.5 shadow-[0_0_30px_rgba(34,211,238,0.3)] mb-12">
              <div className="w-full h-full bg-navy-black rounded-[22px] flex items-center justify-center">
                <span className="text-neon-cyan font-black text-2xl font-display">ML</span>
              </div>
            </div>
            
            <h2 className="text-xl font-bold mb-2 font-display">{t.appLocked}</h2>
            <p className="text-white/40 text-xs mb-8 uppercase tracking-widest">{t.enterPin}</p>
            
            <div className="space-y-8 w-full max-w-[240px]">
              <input 
                type="password"
                value={pinInput}
                onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, '').slice(0, 4);
                  setPinInput(val);
                }}
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-5 text-center text-3xl font-black tracking-[1em] outline-none focus:border-neon-cyan transition-all"
                placeholder="****"
              />
              
              <button 
                onClick={handleUnlock}
                className="w-full h-14 bg-neon-cyan text-navy-black font-black uppercase tracking-[0.2em] rounded-2xl shadow-[0_0_20px_rgba(34,211,238,0.4)] active:scale-95 transition-all"
              >
                {t.unlock}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="fixed top-0 left-0 right-0 z-50 bg-navy-black/60 backdrop-blur-xl border-b border-white/5 h-16 flex items-center px-6">
        <div className="max-w-md mx-auto w-full flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg overflow-hidden border border-white/15 shadow-[0_0_15px_rgba(34,211,238,0.3)]">
            <img src="/app_icon_futuristic.png" alt="My Daily Life Icon" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </div>
          <h1 className="text-[15px] font-extrabold uppercase tracking-[.3em] font-display flex items-center gap-3">
                      <span className="bg-gradient-to-r from-white via-white to-white/60 bg-clip-text text-transparent">MY DAILY LIFE</span>

            <span className="text-neon-pink animate-pulse text-xs">❤️</span>
          </h1>
        </div>
      </div>

      <main className="max-w-md mx-auto px-6 pt-16 relative z-10">
        <AnimatePresence mode="wait">
          {renderScreen()}
        </AnimatePresence>
      </main>

      {/* Floating Bottom Navigation */}
      <nav className="fixed bottom-8 left-1/2 -translate-x-1/2 w-[85%] max-w-md z-50">
        <div className="bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[2rem] h-16 flex items-center justify-around px-4 shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
          <NavBtn active={activeTab === 'home'} icon={<Home size={20} />} onClick={() => setActiveTab('home')} label={t.home} />
          <NavBtn active={activeTab === 'expenses'} icon={<Landmark size={20} />} onClick={() => setActiveTab('expenses')} label={t.expenses} />
          <NavBtn active={activeTab === 'schedule'} icon={<Calendar size={20} />} onClick={() => setActiveTab('schedule')} label={t.schedule} />
          <NavBtn active={activeTab === 'profile'} icon={<User size={20} />} onClick={() => setActiveTab('profile')} label={t.profile} />
        </div>
      </nav>
    </div>
  );
}

function NavBtn({ active, icon, onClick, label }: { active: boolean, icon: React.ReactNode, onClick: () => void, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex flex-col items-center gap-1 transition-all duration-300 p-2 rounded-2xl relative group",
        active ? "text-neon-cyan" : "text-white/40 hover:text-white/70"
      )}
    >
      <div className={cn(
        "relative z-10 p-2 rounded-xl transition-all duration-300",
        active && "bg-neon-cyan/20 shadow-[0_0_15px_rgba(34,211,238,0.2)] scale-110"
      )}>
        {icon}
      </div>
      {active && (
        <motion.div 
          layoutId="nav-dot"
          className="w-1 h-1 bg-neon-cyan rounded-full mt-0.5"
          transition={{ type: 'spring', stiffness: 500, damping: 30 }}
        />
      )}
    </button>
  );
}
